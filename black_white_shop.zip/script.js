function addToCart(name, price) {
  const cart = document.getElementById('cart');
  const item = document.createElement('div');
  item.textContent = `${name} - €${price.toFixed(2)}`;
  cart.appendChild(item);

  const total = document.getElementById('total');
  const currentTotal = parseFloat(total.textContent);
  total.textContent = (currentTotal + price).toFixed(2);
}
